FADI ALBELI — BILINGUAL PORTFOLIO
================================

Files:
- index.html: complete responsive Arabic/English portfolio website.

Preview:
- Open index.html in a browser.

Publish free with GitHub Pages:
1. Create/sign in to a GitHub account.
2. Create a new public repository named: fadi-portfolio
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and /(root), then Save.
7. GitHub will provide the public website URL.

Before publishing:
- Review all personal details and dates.
- Replace the sample project cards with real projects and screenshots.
- Add your CV PDF only if you want it publicly downloadable.
- Confirm that your phone/email/LinkedIn details are current.
